package studentplatform.student_platform.controller;

public class string {

}
