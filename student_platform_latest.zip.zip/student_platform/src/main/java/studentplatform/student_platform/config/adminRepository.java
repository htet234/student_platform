package studentplatform.student_platform.config;

public class adminRepository {

    public static final String adminRepository = null;

}
